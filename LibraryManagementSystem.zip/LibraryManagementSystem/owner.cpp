#include <iostream>
#include "owner.h"
#include "chararrayfunction.h"
//#include "Structure.h"
#include <regex>
#define MAX 100

std::regex bookNameRegx("([A-Za-z]+[ ]*)+");
std::regex bookPriceRegx("([0-9]+[.]*[0-9]+)");

void Owner::addBook(Books* &book, int &bookCount)
{
    char choice;

    do
    {
        ++bookCount;

        book = (Books*)realloc(book, sizeof(Books) * (bookCount + 1));

        // BookId
        book[bookCount].bookId = bookCount + 1;

        // BookName
        while (1)
        {
            char tempName[MAX];
            std::cout << "Enter book name: ";
            std::cin.getline(tempName, MAX);

            if (regex_match(tempName, bookNameRegx))
            {
                charArrayCopy(book[bookCount].bookName, tempName);
                break;
            }

            std::cout << "Invalid book name" << std::endl;
            std::cout << std::endl;
        }

        // BookCategory
        char bookCategory[MAX];
        std::cout << "---------------------------------------------------" << std::endl;
        std::cout << "\t\tBook types" << std::endl;
        std::cout << "---------------------------------------------------" << std::endl;
        std::cout << "1.storyBook\t2.novel" << std::endl;
        std::cout << "3.poetry\t4.religiousBook" << std::endl;
        while (1)
        {
            std::cout << "Choose book category: ";
            std::cin.getline(bookCategory, MAX);

            if ( charArrayLength(bookCategory) == 1 && bookCategory[0] >= '0' && bookCategory[0] < '5' )
            {
                book[bookCount].bookCategory = (BookCategory)atoi(bookCategory);
                break;
            }
            else
            {
                std::cout << "Invalid choice" << std::endl;
                std::cout << std::endl;
            }
         }

        // BookPrice
        while(1)
        {
            char tempPrice[MAX];
            std::cout << "Enter book price: ₹" ;
            std::cin.getline(tempPrice, MAX);

            if (regex_match(tempPrice, bookPriceRegx))
            {
                book[bookCount].bookPrice = atof(tempPrice);
                break;
            }

            std::cout << "Invalid Book Price" << std::endl;
            std::cout << std::endl;
        }

        // BookRentCharges
        while(1)
        {
            char tempRentCharges[MAX];
            std::cout << "Enter book rent charges per day: ₹" ;
            std::cin.getline(tempRentCharges, MAX);

            if (regex_match(tempRentCharges, bookPriceRegx))
            {
                book[bookCount].rentPerDay = atof(tempRentCharges);
                break;
            }

            std::cout << "Invalid Book Rent Price" << std::endl;
            std::cout << std::endl;
        }

        // BookPenaltyCharges
        while(1)
        {
            char tempPenaltyCharges[MAX];
            std::cout << "Enter book penalty charges per day: ₹" ;
            std::cin.getline(tempPenaltyCharges, MAX);

            if (regex_match(tempPenaltyCharges, bookPriceRegx))
            {
                book[bookCount].penaltyPerDay = atof(tempPenaltyCharges);
                break;
            }

            std::cout << "Invalid Book Penalty Price" << std::endl;
            std::cout << std::endl;
        }

        // BookRentDays
        book[bookCount].rentDays = 0;

        // BookStatus
        book[bookCount].bookStatus = AVAILABLE;

        // Charges
        book[bookCount].bookTotalCharges = 0;

        std::cout << std::endl ;

        std::cout << "Do you want to add one more book (Y/y)?: " ;
        std::cin >> choice ;

        std::cin.ignore();

        std::cout << std::endl;

    } while(choice == 'y' || choice == 'Y');
}

void Owner::removeBook(Books* book, int bookCount)
{
    int bookId;

    while(1)
    {
        std::cout << "Enter book Id: ";
        std::cin >> bookId;

        if(bookId > 0 && bookId <= bookCount+1)
        {
                book[bookId-1].bookStatus = DELETED;
                std::cout << "Book removed successfully" << std::endl;
                break;
        }
        else
        {
            std::cout << "Invalid Book Id" << std::endl;
        }
    }
}

void Owner::bookInfo(Books* book, int bookCount, enum BookStatus bookStatus )
{
    int count = 0;

    for (int i=0; i <= bookCount; i++)
    {

        if (book[i].bookStatus == bookStatus || bookStatus == ALL)
        {
            std::cout << "--------------------------------------------" << std::endl;
            std::cout << "\tBook: " << ++count << std::endl;
            std::cout << "--------------------------------------------" << std::endl;

            std::cout << "Book Id:" << book[i].bookId << std::endl;
            std::cout << "Book Name: " << book[i].bookName << std::endl;

            std::cout << "Book Category: ";
            booksCategory(book[i].bookCategory);

            std::cout << "Book Price: ₹" << book[i].bookPrice << std::endl;
            std::cout << "Book Rent Charges:₹" << book[i].rentPerDay << " per day" << std::endl;
            std::cout << "Book Penalty Charges:₹" << book[i].penaltyPerDay << " per extra day" << std::endl;

            if(bookStatus == ONRENT)
            {
                std::cout << "ID of customer who has taken book on rent: " << book[i].cusID << std::endl;
            }
            else if(bookStatus == SOLD)
            {
                std::cout << "ID of customer who has bought the book: " << book[i].cusID << std::endl;
            }
            else if(bookStatus == AVAILABLE)
            {
                std::cout << "Book is not associated to any of customer" << std::endl;
            }
        }
    }

    if (count == 0)
    {
        std::cout << "No any such book is available" << std::endl;
    }

    std::cout<<std::endl;
}

void Owner::viewBooksInfo(Books* book, int bookCount)
{
    char choice[MAX], ch;

    do
    {
        std::cout << "---------------------------------------------------" << std::endl;
        std::cout << "\t\tOptions to View Books"<<std::endl;
        std::cout << "---------------------------------------------------" << std::endl;
        std::cout << "1.Deleted books\t\t\t2.Books taken away on rent" << std::endl;
        std::cout << "3.Books available on rent\t4.All books" << std::endl;
        std::cout << "5.Sold books" << std::endl;

        std::cout << "\nChoose task to perform: ";
        std::cin.getline(choice, MAX);

        if (charArrayLength(choice) == 1 && choice[0] > '0' && choice[0] <= '5')
        {
            switch (atoi(choice))
            {
                case 1:
                    std::cout << "-----------------------------------------------" << std::endl;
                    std::cout << "\t***Deleted books***" << std::endl;
                    std::cout << "-----------------------------------------------" << std::endl;

                    bookInfo(book,bookCount, DELETED);
                    break;
                case 2:
                    std::cout << "-----------------------------------------------" << std::endl;
                    std::cout << "\t***Books taken away on rent***" << std::endl;
                    std::cout << "-----------------------------------------------" << std::endl;

                    bookInfo(book,bookCount, ONRENT);
                    break;
                case 3:
                    std::cout << "-----------------------------------------------" << std::endl;
                    std::cout << "\t***Books available on rent***" << std::endl;
                    std::cout << "-----------------------------------------------" << std::endl;

                    bookInfo(book, bookCount, AVAILABLE);
                    break;
                case 4:
                    std::cout << "-----------------------------------------------" << std::endl;
                    std::cout << "\t***All books***" << std::endl;
                    std::cout << "-----------------------------------------------" << std::endl;

                    bookInfo(book, bookCount, ALL);
                    break;
                case 5:
                    std::cout << "-----------------------------------------------" << std::endl;
                    std::cout << "\t***Sold books***" << std::endl;
                    std::cout << "-----------------------------------------------" << std::endl;

                    bookInfo(book, bookCount, SOLD);
                    break;
                default:
                    std::cout << "Invalid Choice" << std::endl;
                    std::cout << std::endl;
            }
        }
        else
        {
            std::cout << "Invalid choice" << std::endl;
            std::cout << std::endl;
        }

        std::cout << "Do you want to view more books(Y/y)?: ";
        std::cin >> ch;
        std::cin.ignore();
    }while(ch=='Y' || ch=='y');
}

void Owner::ownerCollectedMoney(Books* book, int bookCount)
{
    float totalAmount = 0;

    for(int i=0; i<bookCount; i++)
    {
        totalAmount += book[i].bookTotalCharges;
    }

    std::cout << "Money collected by owner: ₹" << totalAmount << std::endl;
    std::cout << std::endl;
}

void Owner::ownerTask(Books* &book, int &bookCount)
{
    char choice[MAX], ch;

    do
    {
        std::cout << "---------------------------------------------------" << std::endl;
        std::cout << "\tTasks Performed By Library Owner" << std::endl;
        std::cout << "---------------------------------------------------" << std::endl;
        std::cout << "1.Add Book\t\t2.Remove Book" << std::endl;
        std::cout << "3.View Books\t\t4.Money collected by owner" << std::endl;

        std::cout << "\nChoose task to perform: ";
        std::cin.getline(choice, MAX);

        if ( charArrayLength(choice) == 1 )
        {
            switch (atoi(choice))
            {
                case 1:
                    addBook(book, bookCount);
                    break;
                case 2:
                    removeBook(book, bookCount);
                    break;
                case 3:
                    viewBooksInfo(book, bookCount);
                    break;
                case 4:
                    ownerCollectedMoney(book, bookCount);
                    break;
                default:
                    std::cout << "Invalid Choice"<<std::endl;
                    std::cout << std::endl;
            }
        }
        else
        {
            std::cout << "Invalid choice" << std::endl;
            std::cout << std::endl;
        }

        std::cout << "Do you want to perform owner task again ?(Y/y): ";
        std::cin >> ch;
        std::cin.ignore();
        std::cout << std::endl;
    } while (ch == 'Y' || ch == 'y');

}
