#include <iostream>
#include <map>
#include "Structure.h"

void booksCategory(enum BookCategory bookCategory)
{
    // Mapping of enum bookCategory to string message
    std::map<enum BookCategory, std::string> bookCategoryMap;

    bookCategoryMap[STORY] = "Story Book";
    bookCategoryMap[NOVEL] = "Novel Book";
    bookCategoryMap[POETRY] = "Poetry Book";
    bookCategoryMap[RELIGIOUS] = "Religious Book";

    std::cout << bookCategoryMap[bookCategory] << std::endl;
}
