#include <iostream>
#include <regex>
#include "library.h"
#include "chararrayfunction.h"
#define MAX 100

std::regex customerIdRegex("[0-9]+");

Library::Library():
    m_books(NULL),
    m_customerData(NULL),
    m_bookCount(0),
    m_customerCount(0)
{

}

void Library::defaultBooks() // Three default books are added
{
    m_books = (Books *)malloc(sizeof(Books) * (3));

    m_books[m_bookCount].bookId = m_bookCount + 1;
    char tempName1[] = "Bhagvad Geeta";
    charArrayCopy(m_books[m_bookCount].bookName, tempName1);
    m_books[m_bookCount].bookCategory = RELIGIOUS;
    m_books[m_bookCount].bookPrice = 879.98;
    m_books[m_bookCount].rentPerDay = 13.25;
    m_books[m_bookCount].penaltyPerDay = 17.5;
    m_books[m_bookCount].rentDays = 0;
    m_books[m_bookCount].bookTotalCharges = 0;
    m_books[m_bookCount].bookStatus = AVAILABLE;

    m_bookCount++;
    m_books[m_bookCount].bookId = m_bookCount + 1;
    char tempName2[MAX]="Night Sky with Exit Wounds";
    charArrayCopy(m_books[m_bookCount].bookName,tempName2);
    m_books[m_bookCount].bookCategory = POETRY;
    m_books[m_bookCount].bookPrice = 534.10;
    m_books[m_bookCount].rentPerDay = 6.25;
    m_books[m_bookCount].penaltyPerDay = 9;
    m_books[m_bookCount].rentDays = 0;
    m_books[m_bookCount].bookTotalCharges = 0;
    m_books[m_bookCount].bookStatus = AVAILABLE;

    m_bookCount++;
    m_books[m_bookCount].bookId = m_bookCount + 1;
    char tempName3[] = "Shivba Raje";
    charArrayCopy(m_books[m_bookCount].bookName,tempName3);
    m_books[m_bookCount].bookCategory = STORY;
    m_books[m_bookCount].bookPrice = 676.8;
    m_books[m_bookCount].rentPerDay = 7.7;
    m_books[m_bookCount].penaltyPerDay = 11;
    m_books[m_bookCount].rentDays = 0;
    m_books[m_bookCount].bookTotalCharges = 0;
    m_books[m_bookCount].bookStatus = AVAILABLE;
}

int Library::logInTypes()
{
    char choice[MAX];

    std::cout << "---------------------------------------------------" << std::endl;
    std::cout << "\t\tLogin Types" << std::endl;
    std::cout << "---------------------------------------------------" << std::endl;
    std::cout << "1.Owner\t\t\t2.Customer" << std::endl;
    std::cout << std::endl;

    while(1)
    {
        std::cout << "Enter valid choice ==> ";
        std::cin.getline(choice, MAX);

        if (charArrayLength(choice) == 1 && (choice[0]=='1' || choice[0]=='2'))
        {
            break;
        }
        else
        {
            std::cout << "Invalid choice" << std::endl;
            std::cout << std::endl;
        }
    }

    return atoi(choice);
}

void Library::addNewCustomer()
{
    if(m_customerData == NULL)
    {
        m_customerData = (Customer*)malloc(sizeof(Customer)*(m_customerCount+1));
    }
    else
    {
        m_customerData = (Customer*)realloc(m_customerData,sizeof(Customer)*(m_customerCount+1));
    }

    m_customerData[m_customerCount].setId(m_customerCount+1);
    m_customerData[m_customerCount].setPassword();
    m_customerData[m_customerCount].setDeposit();

    std::cout << "\nSigned up successfully" << std::endl;
    std::cout << "---Your login credentials---" << std::endl;
    std::cout << "Login ID : "<< m_customerData[m_customerCount].getId() << std::endl;
    std::cout << "PassWord : "<< m_customerData[m_customerCount].getPassword() << std::endl;
    std::cout << "Deposit : ₹"<< m_customerData[m_customerCount].getDeposit() << std::endl;

    m_customerCount++;
    std::cout << std::endl;
}

void Library::printBookInfo(int bookId)
{
    if ( !(bookId > 0 && bookId <= m_bookCount) )
    {
        std::cout << "Invalid Book Id" << std::endl;
        return;
    }
    else
    {
        std::cout << "Book Id:" << m_books[bookId-1].bookId << std::endl;
        std::cout << "Book Name: " << m_books[bookId-1].bookName << std::endl;

        std::cout << "Book Category: ";
        booksCategory(m_books[bookId-1].bookCategory);

        std::cout << "Book Price: ₹" << m_books[bookId-1].bookPrice << std::endl;
        std::cout << "Book Rent Charges:₹" << m_books[bookId-1].rentPerDay << " per day" << std::endl;
        std::cout << "Book Penalty Charges:₹" << m_books[bookId-1].penaltyPerDay << " per extra day" << std::endl;
    }
}

void Library::tasks()  // Performing tasks according to role
{
    char choice[MAX], ch;

    do
    {
        switch (logInTypes()) // Choosing login types
        {
            case 1:
                if (m_owner.getId() != 11)
                {
                    m_owner.setId(11);
                    m_owner.setPassword();
                    std::cout << "Signed up successfully" << std::endl;
                    std::cout << "---Your login credentials---" << std::endl;
                    std::cout << "Login ID : " << m_owner.getId() << std::endl;
                    std::cout << "PassWord : " << m_owner.getPassword() << std::endl;
                }

                m_owner.ownerTask(m_books, m_bookCount);
                break;
            case 2:
                std::cout << "---------------------------------------------------" << std::endl;
                std::cout << "1. Sign Up\t\t2. Log In" << std::endl;
                std::cout << "---------------------------------------------------" << std::endl;
                std::cout << std::endl;

                while(1)
                {
                    std::cout << "Enter your choice ==> ";
                    std::cin.getline(choice, MAX);

                    if (charArrayLength(choice) == 1 && (choice[0]=='1' || choice[0]=='2'))
                    {
                        break;
                    }
                    else
                    {
                        std::cout << "Invalid choice" << std::endl;
                    }
                    std::cout << std::endl;
                }

                switch (atoi(choice))
                {
                    case 1:
                        addNewCustomer();
                    case 2:
                        if(m_customerCount==0)
                        {
                            std::cout << "No any customer logged in" << std::endl;
                            break;
                        }

                        while (1)
                        {
                            char id[MAX];
                            std::cout << "Enter valid ID to log in: ";
                            std::cin.getline(id, MAX);

                            if(regex_match(id, customerIdRegex))
                            {
                                if (atoi(id) > 0 && atoi(id) <= m_customerCount+1)
                                {
                                    std::cout << "Successfully logged in !!!" << std::endl;
                                    std::cout << std::endl;
                                    m_customerData[atoi(id) -1].customerTask(m_books,m_bookCount);
                                    break;
                                }
                                else
                                {
                                    std::cout << "Customer ID not matched" << std::endl;
                                    std::cout << std::endl;
                                }
                            }
                            else
                            {
                                std::cout << "Invalid Customer ID" << std::endl;
                                std::cout << std::endl;
                            }
                        }
                        break;
                    default:
                        std::cout << "Invalid Choice" << std::endl;
                }
        }

        std::cout << "\nDo you want to log in again(Y/y)?: ";
        std::cin >> ch;
        std::cin.ignore();
        std::cout << std::endl;

    } while (ch == 'y' || ch == 'Y');
}

Library::~Library()
{
    free(m_books);
    free(m_customerData);
}

