#ifndef LIBRARY_H
#define LIBRARY_H

//#include "Structure.h"
#include "owner.h"
#include "customer.h"

class Library
{
    public:
        //friend class Customer;

        Library();
        ~Library();

        /*
         *  Function to add books intially in library
         */
        void defaultBooks();

        // To perform tasks according to login type
        void tasks();

        /**
         * To display details of a particular book
         *
         * @param int[in], BookId
         */
        void printBookInfo(int);
    private:
        // To choose login type as Customer OR Owner
        int logInTypes();

        // Signup of new customer
        void addNewCustomer();

        Books* m_books;
        Owner m_owner;
        Customer* m_customerData;

        int m_bookCount;
        int m_customerCount;
};


#endif // LIBRARY_H
