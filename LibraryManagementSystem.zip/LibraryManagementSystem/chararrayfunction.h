#ifndef CHARARRAYFUNCTION_H
#define CHARARRAYFUNCTION_H

/**
 * To calculate character array length
 *
 * @param char*[in], pointer of character array
 * @return int[out], Character array length
 */
int charArrayLength(char arr[]);

/**
 *  To copy character array from source to destination
 *
 *  @param char*&[in], Reference to character pointer
 */
void charArrayCopy(char* &, char []);

#endif // CHARARRAYFUNCTION_H
