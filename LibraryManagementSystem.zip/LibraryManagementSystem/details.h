#ifndef DETAILS_H
#define DETAILS_H

class Details
{
    public:
        Details();
        ~Details();

        void setId(int);
        int getId() const;

        void setPassword();
        char* getPassword() const;
    private:
        int m_id;
        char* m_password;
};

#endif // DETAILS_H
