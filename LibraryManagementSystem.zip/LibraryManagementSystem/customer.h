 #ifndef CUSTOMER_H
#define CUSTOMER_H

#include "details.h"
#include "Structure.h"

class Customer : public Details
{
    public:
        Customer();
        ~Customer();

        /**
         * Choose customer task to perform action in library
         *
         * @param books[in] which is book struct pointer
         * @param int[in], Count of books
         */
        void customerTask(Books*, int);

        void setDeposit();
        float getDeposit() const;

    private:
        /**
         * To view books available for rent and buy
         *
         * @param books[in] which is book struct pointer
         * @param int[in], Count of books
         */
        void viewAvailBook(Books* &, int);

        /**
         * To choose book/books on rent OR buy
         *
         * @param books[in] which is book struct pointer
         * @param int[in], Count of books
         */
        void chooseBook(Books*, int);

        /**
         * Funtion to return book in library which taken on rent
         *
         * @param books[in] which is book struct pointer
         * @param int[in], Count of books
         */
        void returnBook(Books*, int);

        // Customer deposit amount
        float m_depositAmount ;
};

#endif // CUSTOMER_H
