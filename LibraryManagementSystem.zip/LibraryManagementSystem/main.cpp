#include <iostream>
#include "library.h"

// argc and argv are commandline argument
int main(int argc, char** argv)
{
    std::cout<<"Number of arguments : "<<argc<<std::endl;

    for(int i =0; i < argc; i++)
    {
        std::cout<<"Arguments "<<i<<" :"<<argv[i]<<std::endl;
    }
    Library library;

    std::cout << "\t\t!!!...WelCome...!!!" << std::endl;

    library.defaultBooks();      // Adding three default books
    library.tasks();

    std::cout << "Thank You. Visit Again...!!" << std::endl;

    return 0;
}
