#include <iostream>
#include <cstring>
#include "details.h"
#include "chararrayfunction.h"
#include <regex>
#define MAX 100

std::regex passwardFormatRegx ("([A-Za-z]{4}[@][0-9]{4})+");

Details::Details()
{
    m_id = 0;
    m_password = NULL;
}

void Details::setId(int id)
{
    m_id = id;
}

int Details::getId() const
{
    return m_id;
}

void Details::setPassword()
{
    char tempName[MAX] = {'\0'};

    while (1)
    {
        std::cout << "Enter password to login: " << std::endl;
        std::cout << "(First four character as alphabet, after that @ and after that four digit at end) " << std::endl ;
        std::cin.getline(tempName, MAX);

        if (regex_match(tempName, passwardFormatRegx))
        {
            break;
        }

        std::cout << "Invalid password" << std::endl;
        std::cout << std::endl;
    }

    //charArrayCopy(m_password, tempName);
    m_password = strdup( tempName);
    std::cout << std::endl;
}

char* Details::getPassword() const
{
    return m_password;
}

Details::~Details()
{
    free(m_password);
}




