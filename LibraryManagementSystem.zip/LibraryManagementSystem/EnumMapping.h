#ifndef STRUCTURE_H
#define STRUCTURE_H

enum BookCategory  // Enum for book category
{
    STORY ,
    NOVEL,
    POETRY ,
    RELIGIOUS
};

enum BookStatus  // Enum for book status
{
    DELETED ,
    ONRENT ,
    AVAILABLE ,
    SOLD ,
    ALL
};

struct Books  // Structure for storing book data
{
    int bookId ;
    char* bookName ;
    float bookPrice ;
    float rentPerDay ;
    float penaltyPerDay ;
    float rentDays ;
    enum BookStatus bookStatus ;
    enum BookCategory bookCategory ;
    float bookTotalCharges ;
    int cusID ;
};

// Mapping of enum bookCategory to string message
void booksCategory(enum BookCategory);

#endif // STRUCTURE_H
