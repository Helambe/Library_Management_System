#ifndef OWNER_H
#define OWNER_H

#include "Structure.h"
#include "details.h"

class Owner : public Details
{
    private:
        /*
         * Add new book into the library
         *
         * @param books*&[in] which is book struct pointer reference
         * @param int&[in], Reference to Count of books
         */
        void addBook(Books* &, int &);

        void removeBook(Books*, int); // Removing book by entering Book Id
        void viewBooksInfo(Books*, int); // Choosing BookCategory to display book details
        void ownerCollectedMoney(Books*, int); // Displaying money collected by owner from book rent and selling books
        void bookInfo(Books*, int, enum BookStatus ); // Viewing book details according to bookCategory
    public:
        /*
         * To choose task performed by owner of library
         */
        void ownerTask(Books* &, int &);
};

#endif // OWNER_H
