#include <stdlib.h>
#include "chararrayfunction.h"

int charArrayLength(char arr[])
{
    int i = 0;
    while (arr[i] != '\0')
    {
        i++;
    }
    return i;
}

void charArrayCopy(char* &dest, char src[])
{
    // Memory allocation to dest char pointer
    //dest = (char*) malloc(charArrayLength(src) * sizeof(char));
    dest = new char[charArrayLength(src)];

    // Copying element from src to dest
    for (int i = 0; src[i] != '\0'; i++)
    {
        dest[i] = src[i];
    }
}


