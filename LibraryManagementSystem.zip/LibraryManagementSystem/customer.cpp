#include <iostream>
#include <regex>
#include "customer.h"
//#include "Structure.h"
#include "chararrayfunction.h"
#define MAX 100

std::regex depositRegx("([0-9]+[.]*[0-9]+)");

Customer::Customer()
{
    m_depositAmount = 0;
}

Customer::~Customer()
{

}

void Customer::setDeposit()
{
    char tempDeposit[MAX];

    while (1)
    {
        std::cout << "Enter deposit amount of minimum ₹500: ₹";
        //std::cin.ignore();
        std::cin.getline(tempDeposit, MAX);

        if(regex_match(tempDeposit, depositRegx))
        {
            if (atof(tempDeposit) >= 500)
            {
                m_depositAmount = atof(tempDeposit);
                break;
            }
            else
            {
                std::cout << "Invalid amount" << std::endl;
                std::cout << std::endl;
            }
        }
        else
        {
                std::cout << "Invalid Amount" << std::endl;
                std::cout << std::endl;
        }
    }
}

float Customer::getDeposit() const
{
    return m_depositAmount;
}

void Customer::viewAvailBook(Books* &book, int bookCount)
{
    int count = 0;

    std::cout << "List of available books:" << std::endl;
    for (int i = 0; i <= bookCount; i++)
    {
        if (book[i].bookStatus == AVAILABLE)
        {
            std::cout << "-----------------------------------------------" << std::endl;
            std::cout << "\tBook: " << ++count << std::endl;
            std::cout << "-----------------------------------------------" << std::endl;

            std::cout << "Book Id:" << book[i].bookId << std::endl;
            std::cout << "Book Name: " << book[i].bookName << std::endl;

            std::cout << "Book Category: ";
            booksCategory(book[i].bookCategory);

            std::cout << "Book Price: ₹" << book[i].bookPrice << std::endl;
            std::cout << "Book Charges: ₹" << book[i].rentPerDay << " per day" << std::endl;
            std::cout << "Book Penalty Charges: ₹" << book[i].penaltyPerDay << " per extra day" << std::endl;
        }
    }

    if (count == 0)
    {
        std::cout << "Books are not available" << std::endl;
    }
}

void Customer::chooseBook(Books* book, int bookCount)
{
    char ch;
    int bookId;

    do
    {
        std::cout << "-----------------------------------------------" << std::endl;
        std::cout << "\tChoice to choose book" << std::endl;
        std::cout << "-----------------------------------------------" << std::endl;
        std::cout << "1.Buy book\t2.Take book on rent" << std::endl;
        std::cout << std::endl;

        std::cout << "Enter your choice: ";
        char choice[MAX];
        std::cin.getline(choice, MAX);

        if (charArrayLength(choice) == 1 && (choice[0] == '1' || choice[0] == '2'))
        {
            std::cout << "Enter book Id: ";
            std::cin >> bookId;

            if(bookId > 0 && bookId <= bookCount+1)
            {
                switch (atoi(choice))
                {
                    case 1:
                        std::cout << "Book Price: ₹" << book[bookId-1].bookPrice << std::endl;
                        book[bookId-1].bookTotalCharges += book[bookId-1].bookPrice;
                        std::cout << "Book sold out successfully" << std::endl;
                        book[bookId-1].bookStatus = SOLD;
                        book[bookId-1].cusID = getId();
                        std::cout << std::endl;
                        break;
                    case 2:
                        std::cout << "Enter number of days for which you want book" << std::endl;
                        std::cin >> book[bookId-1].rentDays;
                        std::cout << "Expected total rent charges for book: ₹" << book[bookId-1].rentDays * book[bookId-1].rentPerDay << std::endl;
                        std::cout << "Book successfully issued to customer" << std::endl;
                        book[bookId-1].bookStatus = ONRENT;
                        book[bookId-1].cusID = getId();
                        std::cout << std::endl;
                        break;
                }
            }
            else
            {
                std::cout << "Invalid Book Id" << std::endl;
                std::cout << std::endl;
            }
        }
        else
        {
            std::cout << "Invalid Choice" << std::endl;
            std::cout << std::endl;
        }

        std::cout << "Do you want to choose more books(Y/y)?:" ;
        std::cin >> ch;
        std::cin.ignore();
        std::cout << std::endl;
    } while (ch == 'y' || ch == 'Y');
}

void Customer::returnBook(Books* book, int bookCount)
{
    float actualRentDays;
    int bookId;

    std::cout << "Enter book Id: ";
    std::cin >> bookId;

    if (book[bookId-1].bookStatus == ONRENT && book[bookId-1].cusID == getId())
    {
        std::cout << "Enter actual rent days: ";
        std::cin >> actualRentDays;

        if (actualRentDays > book[bookId-1].rentDays)
        {
            std::cout << "Penalty charges: ₹" << (actualRentDays - book[bookId-1].rentDays) * book[bookId-1].penaltyPerDay << std::endl;
            book[bookId-1].bookTotalCharges += book[bookId-1].rentPerDay*book[bookId-1].rentDays+(actualRentDays - book[bookId-1].rentDays) * book[bookId-1].penaltyPerDay;
        }
        else
        {
            std::cout << "No penalty charges" << std::endl;
            book[bookId-1].bookTotalCharges+=book[bookId-1].rentPerDay*book[bookId-1].rentDays;
        }

        std::cout << "Book returned successfully!!" << std::endl;
        book[bookId-1].bookStatus = AVAILABLE;
        book[bookId-1].rentDays=0;
    }
    else
    {
        std::cout << "Information Mismatched" << std::endl;
    }
}

void Customer::customerTask(Books* book, int bookCount)
{
    char choice[MAX], ch;

    //std::cin.ignore();

    do
    {
        std::cout << "-----------------------------------------------" << std::endl;
        std::cout << "\tTasks performed by customer" << std::endl;
        std::cout << "-----------------------------------------------" << std::endl;
        std::cout << "1.View Available Books\t2.Choose Book(Buy or Rent)" << std::endl;
        std::cout << "3.Return book" << std::endl;

        std::cout << "\nChoose task to perform: ";
        //std::cin.ignore();
        std::cin.getline(choice, MAX);

        if (charArrayLength(choice) == 1)
        {
            switch (atoi(choice))
            {
                case 1:
                    viewAvailBook(book, bookCount);
                    break;
                case 2:
                    chooseBook(book, bookCount);
                    break;
                case 3:
                    returnBook(book, bookCount);
                    break;
                default:
                    std::cout << "Invalid Choice switch" << std::endl;
                    std::cout << std::endl;
            }
        }
        else
        {
            std::cout << "Invalid choice" << std::endl;
            std::cout << std::endl;
        }

        std::cout << "Do you want to perform customer another task(Y/y)?: ";
        std::cin >> ch;
        std::cin.ignore();
        std::cout << std::endl;
    } while (ch == 'Y' || ch == 'y');
}
